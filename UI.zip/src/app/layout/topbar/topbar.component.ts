import {
  Component,
  Output,
  EventEmitter,
  inject,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { CommonService } from '../../pages/common.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [],
  templateUrl: './topbar.component.html',
  styleUrl: './topbar.component.css'
})
export class TopbarComponent {
  @Output() toggleSidebar = new EventEmitter<void>();

  readonly commonService = inject(CommonService);
  designationId = Number(localStorage.getItem('Designation_ID') || '3');
  isRoleModeEnabled = false;
  private roleModeSubscription?: Subscription;

  ngOnInit() {
    this.commonService.initializeRoleFlagsFromDesignation(this.designationId);

    if (this.designationId === 1) {
      this.roleModeSubscription = this.commonService.isManagerMode$.subscribe(
        (isEnabled) => {
          this.isRoleModeEnabled = isEnabled;
        },
      );
      return;
    }

    if (this.designationId === 2) {
      this.roleModeSubscription = this.commonService.isLeadMode$.subscribe(
        (isEnabled) => {
          this.isRoleModeEnabled = isEnabled;
        },
      );
      return;
    }

    this.isRoleModeEnabled = false;
  }

  ngOnDestroy() {
    this.roleModeSubscription?.unsubscribe();
  }

  get canToggleRoleMode(): boolean {
    return this.designationId === 1 || this.designationId === 2;
  }

  get roleToggleLabel(): string {
    return this.designationId === 1 ? 'Manager Mode' : 'Team Lead Mode';
  }

  get roleToggleHint(): string {
    return this.isRoleModeEnabled ? 'Team View' : 'My View';
  }

  onRoleToggle() {
    const nextState = !this.isRoleModeEnabled;
    this.commonService.toggleRoleMode(nextState, this.designationId);
  }
}
